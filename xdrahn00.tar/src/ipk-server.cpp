/**
 * Name:							Lukáš Drahník
 * Project: 					IPK: Varianta 2: Klient-server pro jednoduchý přenos souborů (Veselý)
 * Date:							8.3.2018
 * Email:						  <xdrahn00@stud.fit.vutbr.cz>, <ldrahnik@gmail.com>
 */

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <iostream>
#include <pthread.h>
#include <netdb.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <math.h>

#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>

#include <arpa/inet.h>
#include <netinet/ip_icmp.h>
#include <netinet/icmp6.h>

using namespace std;

/**
 * When is pressed ctrl+c.
 */
static int G_break = 0;

/**
 * Help message.
 */
const char *HELP_MSG = {
  "Example of usage:\n\n"
  "./ipk-server [-h] -p <port> \n\n"
  "Options:\n"
  "-h  -- show help message\n"
  "-p <port>  - specification port\n"
};

/**
 * Signal handler.
 */
void catchsignal(int sig) {
  if(sig == SIGINT) {
    G_break = 1;
  }
}

/**
 * Terminal parameters:
 */
typedef struct params {
  int show_help_message;              // option h
  int port;                           // option p
  int ecode;                          // error code
} TParams;


/**
 * Get TParams structure from terminal options, option arguments and nodes.
 *
 * @return TParams
 */
TParams getParams(int argc, char *argv[]) {

  // default params
  TParams params = { 0, 0, -1, EOK };

  // strtol endptr
  char *end_ptr;

  // don't want getopt() writing to stderr
  opterr = 0;

  // getopt
  int c;
  while ((c = getopt(argc, argv, "hp:")) != -1) {
    switch (c) {
      case 'h':
        params.show_help_message = 1;
        break;
      case 'p':
        params.port = strtol(optarg, &end_ptr, 10);
        if(*end_ptr != '\0' || *end_ptr == '\n' || params.port < 0) {
          fprintf (stderr, "Option -%c requires an non negative int.\n", c);
          params.ecode = EOPT;
        }
        break;
      case '?':
        if(isprint (optopt)) {
          fprintf (stderr, "Unknown option `-%c'.\n", optopt);
        } else {
          fprintf (stderr, "Unknown option character `\\x%x'.\n", optopt);
        }
        params.ecode = EOPT;
      default:
        fprintf (stderr, "At least one node is required.\n");
        params.ecode = EOPT;
    }
  }

  return params;
}
